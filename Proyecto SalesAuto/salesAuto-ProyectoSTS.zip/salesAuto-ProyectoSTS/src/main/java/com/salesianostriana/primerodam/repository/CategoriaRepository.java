package com.salesianostriana.primerodam.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.salesianostriana.primerodam.modelo.Categoria;

public interface CategoriaRepository extends JpaRepository<Categoria, Long>{


}